<?php
 // created: 2016-12-07 11:13:38
$dictionary['Opportunity']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>