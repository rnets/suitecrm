<?php
 // created: 2016-12-07 11:37:59
$dictionary['Opportunity']['fields']['rfs_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['rfs_c']['options']='date_range_search_dom';
$dictionary['Opportunity']['fields']['rfs_c']['labelValue']='Deliver Date';
$dictionary['Opportunity']['fields']['rfs_c']['enable_range_search']='1';

 ?>