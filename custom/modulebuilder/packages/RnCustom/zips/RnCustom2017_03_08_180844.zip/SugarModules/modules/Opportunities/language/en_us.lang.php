<?php 
 // created: 2017-03-08 18:08:43
$mod_strings['LBL_OID_C'] = 'OID';
$mod_strings['LBL_AMOUNT_USDOLLAR'] = 'Amount in SGD';
$mod_strings['LBL_RFS'] = 'Deliver Date';
$mod_strings['LBL_ACCOUNTS_OPPORTUNITIES_1_FROM_ACCOUNTS_TITLE'] = 'End Customer';

?>
