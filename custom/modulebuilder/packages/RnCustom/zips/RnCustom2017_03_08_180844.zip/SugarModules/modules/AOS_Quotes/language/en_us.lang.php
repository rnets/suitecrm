<?php 
 // created: 2017-03-08 18:08:43
$mod_strings['LBL_PRODUCT_QUANITY'] = 'QTY';

?>
